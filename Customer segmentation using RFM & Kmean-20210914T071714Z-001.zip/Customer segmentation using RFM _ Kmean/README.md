# MIAI_Customer_Segmentation
Demo of using RFM for Customer Segmentation

Link clip: https://youtu.be/I3Oo__t_mks<br>

#MìAI <br>
Fanpage: http://facebook.com/miaiblog<br>
Group trao đổi, chia sẻ: https://www.facebook.com/groups/miaigroup<br>
Website: http://miai.vn<br>
Youtube: http://bit.ly/miaiyoutube<br>
